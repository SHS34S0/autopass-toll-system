CREATE VIEW "all_passages" AS
SELECT
    "passages"."id" AS "passage_id",
    "passages"."passed_at",
    "vehicles"."car_num",
    "toll_stations"."name" AS "station",
    "toll_stations"."base_price",
    "vehicles"."discount_percent",

--Rush Hour Logic
--Morning (07:00-08:30) and Evening (15:30-17:00) -> Markup +20% (x1.2)
    CASE
        WHEN (CAST(strftime('%H', "passages"."passed_at") AS INTEGER) = 7) -- 07:00-07:59
          OR (CAST(strftime('%H', "passages"."passed_at") AS INTEGER) = 8 AND CAST(strftime('%M', "passages"."passed_at") AS INTEGER) <= 30) -- 08:00-08:30
          OR (CAST(strftime('%H', "passages"."passed_at") AS INTEGER) = 15 AND CAST(strftime('%M', "passages"."passed_at") AS INTEGER) >= 30) -- Норвезький пік часто з 15:30
          OR (CAST(strftime('%H', "passages"."passed_at") AS INTEGER) = 16)
        THEN 1.2 --+20% surcharge during rush hour
        ELSE 1.0
    END AS "time_multiplier",

    -- Фінальна формула
    CAST(
    ROUND(
        ("toll_stations"."base_price" * (100 - "vehicles"."discount_percent") / 100) * -- Базова зі знижкою
        CASE
            WHEN (CAST(strftime('%H', "passages"."passed_at") AS INTEGER) = 7) -- 07:00-07:59
            OR (CAST(strftime('%H', "passages"."passed_at") AS INTEGER) = 8 AND CAST(strftime('%M', "passages"."passed_at") AS INTEGER) <= 30) -- 08:00-08:30
            OR (CAST(strftime('%H', "passages"."passed_at") AS INTEGER) = 15 AND CAST(strftime('%M', "passages"."passed_at") AS INTEGER) >= 30) -- Норвезький пік часто з 15:30
            OR (CAST(strftime('%H', "passages"."passed_at") AS INTEGER) = 16)
            THEN 1.2
            ELSE 1.0
        END
    )
    AS INTEGER) AS "final_price_ore"

FROM "passages"
JOIN "vehicles" ON "passages"."car_num" = "vehicles"."car_num"
JOIN "toll_stations" ON "passages"."station_id" = "toll_stations"."id";

