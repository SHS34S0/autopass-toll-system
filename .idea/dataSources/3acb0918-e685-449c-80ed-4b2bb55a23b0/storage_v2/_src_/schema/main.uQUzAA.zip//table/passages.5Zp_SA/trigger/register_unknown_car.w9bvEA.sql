CREATE TRIGGER "register_unknown_car"
BEFORE INSERT ON "passages"
FOR EACH ROW
WHEN NOT EXISTS (SELECT 1 FROM "vehicles" WHERE "car_num" = NEW."car_num")
BEGIN
    INSERT INTO "vehicles" ("car_num")
    VALUES (NEW."car_num");
END;

